const client = require("../_data/client.json");

module.exports = {
    sitemap: {
        hostname: client.domain,
    },
};
