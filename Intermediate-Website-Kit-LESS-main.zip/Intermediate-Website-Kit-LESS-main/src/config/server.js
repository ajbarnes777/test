module.exports = {
    isProduction: process.env.ELEVENTY_ENV === "PROD",
};
